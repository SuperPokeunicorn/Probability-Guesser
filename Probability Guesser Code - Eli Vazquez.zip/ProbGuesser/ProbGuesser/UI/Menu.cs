﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class Menu
    {
        public Menu()
        {
            screens = new Stack<MenuScreen>();
        }

        Stack<MenuScreen> screens;

        public void AddScreen(MenuScreen m)
        {
            screens.Push(m);
        }

        public void CloseScreen()
        {
            screens.Pop();
        }

        public bool IsOpen()
        {
            return screens.Count > 0;
        }

        public void NavigateUp()
        {
            screens.Peek().NavigateUp();
        }

        public void NavigateDown()
        {
            screens.Peek().NavigateDown();
        }

        public void Left()
        {
            screens.Peek().Left();
        }

        public void Right()
        {
            screens.Peek().Right();
        }

        public void Select()
        {
            screens.Peek().Select();
        }

        public void Back()
        {
            screens.Peek().Back();
        }

        public void HeldLeft()
        {
            screens.Peek().HeldLeft();
        }

        public void HeldRight()
        {
            screens.Peek().HeldRight();
        }

        public void Draw()
        {
            screens.Peek().Draw();
        }
    }
}
