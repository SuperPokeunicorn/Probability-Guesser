﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuSFXSlider : MenuSlider
    {
        public MenuSFXSlider(MenuScreen screen) : base(screen, "SFX Volume", 0)
        {
            SetPoints((int)(ResourceManager.GetSFXVolume() * GetMaxPoints()));
        }

        public override void OnSetPoints()
        {
            ResourceManager.SetSFXVolume(((float)GetPoints()) / GetMaxPoints());
        }
    }
}
