﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser
{
    abstract class UIElement
    {
        public UIElement(Vector2 position)
        {
            this.position = position;
            removeMe = false;
        }

        protected Vector2 position;
        public bool removeMe;

        public abstract void Update();

        public abstract void Draw();
    }
}
