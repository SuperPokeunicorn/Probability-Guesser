﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuVideoNavigation : MenuText
    {
        public MenuVideoNavigation(MenuScreen screen) : base(screen, "Video")
        {

        }

        public override void Select()
        {
            MenuScreen newScreen = new MenuScreen(screen.GetMenu(), "Video", Color.Black, 100);
            newScreen.AddOption(new MenuWindowSizeSelector(newScreen));
            newScreen.AddOption(new MenuFullScreen(newScreen));
            newScreen.AddOption(new MenuBackNavigation(newScreen));
            screen.GetMenu().AddScreen(newScreen);
            ResourceManager.PlaySFX("Good");
        }
    }
}