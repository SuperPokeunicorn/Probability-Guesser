﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuQuitGame : MenuText
    {
        public MenuQuitGame(MenuScreen screen, string text = "Quit") : base(screen, text)
        {

        }

        public override void Select()
        {
            ProbGuesser.quitGame = true;
        }
    }
}
