﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuWindowSizeSelector : MenuSelector
    {
        public MenuWindowSizeSelector(MenuScreen screen) : base(screen, "Window Size", new List<string> { "x1", "x2", "x3", "x4" })
        {

        }

        protected override Color GetTextColor(int i)
        {
            if (i + 1 == ProbGuesser.GetScale()) return Color.Red;
            return Color.White;
        }

        protected override void OnSelect(int i)
        {
            ProbGuesser.SetScale(i + 1);
        }
    }
}
