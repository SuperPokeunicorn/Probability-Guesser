﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    abstract class MenuOption
    {
        public MenuOption(MenuScreen screen, int height = 9, int repeatTime = 10)
        {
            this.screen = screen;
            this.height = height;
            leftTimer = 0;
            rightTimer = 0;
            this.repeatTime = repeatTime;
        }

        public abstract void Draw(Vector2 position);
        
        public virtual void DrawCursor(Vector2 position)
        {
            ResourceManager.DrawText(position - new Vector2(8, 0), ">", g: 0, b: 0);
        }

        protected int height;
        protected MenuScreen screen;
        private int leftTimer, rightTimer;
        protected int repeatTime;
        protected bool holdTimer = true;

        public int GetHeight()
        {
            return height;
        }

        public void Left()
        {
            leftTimer = 0;
            OnLeft();
        }

        public abstract void OnLeft();

        public void Right()
        {
            rightTimer = 0;
            OnRight();
        }

        public abstract void OnRight();

        public abstract void Select();

        public void Back()
        {
            screen.Close();
            ResourceManager.PlaySFX("Hit");
        }

        public void HeldLeft()
        {
            if (!holdTimer) return;
            leftTimer++;
            if(leftTimer >= repeatTime)
            {
                Left();
            }
        }

        public void HeldRight()
        {
            if (!holdTimer) return;
            rightTimer++;
            if (rightTimer >= repeatTime)
            {
                Right();
            }
        }
    }
}
