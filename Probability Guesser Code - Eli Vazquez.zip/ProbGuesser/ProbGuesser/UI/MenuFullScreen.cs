﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuFullScreen : MenuText
    {
        public MenuFullScreen(MenuScreen screen) : base(screen, "FullScreen")
        {

        }

        public override void Select()
        {
            ProbGuesser.SetFullscreen(!ProbGuesser.GetFullscreen());
            ResourceManager.PlaySFX("Good");
        }

        public override void Draw(Vector2 position)
        {
            if (ProbGuesser.GetFullscreen()) color = Color.Red;
            else color = Color.White;
            base.Draw(position);
        }
    }
}
