﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuText : MenuOption
    {
        public MenuText(MenuScreen screen, String text):base(screen)
        {
            this.text = text;
            color = Color.White;
        }

        String text;
        protected Color color;

        public override void Draw(Vector2 position)
        {
            ResourceManager.DrawText(position, text, r: color.R, g: color.G, b: color.B);
        }

        public override void OnLeft()
        {
        }

        public override void OnRight()
        {
        }

        public override void Select()
        {
            ResourceManager.PlaySFX("Hit");
        }
    }
}
