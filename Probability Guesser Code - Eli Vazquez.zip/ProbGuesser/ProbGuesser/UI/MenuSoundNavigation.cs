﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuSoundNavigation : MenuText
    {
        public MenuSoundNavigation(MenuScreen screen) : base(screen, "Sound")
        {

        }

        public override void Select()
        {
            MenuScreen newScreen = new MenuScreen(screen.GetMenu(), "Sound", Color.Black, 100);
            newScreen.AddOption(new MenuMusicSlider(newScreen));
            newScreen.AddOption(new MenuSFXSlider(newScreen));
            newScreen.AddOption(new MenuMasterVolumeSlider(newScreen));
            newScreen.AddOption(new MenuBackNavigation(newScreen));
            screen.GetMenu().AddScreen(newScreen);
            ResourceManager.PlaySFX("Good");
        }
    }
}
