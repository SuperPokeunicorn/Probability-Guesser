﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuScreen
    {
        public MenuScreen(Menu menu, String title, Color color, int opacity = 0)
        {
            this.menu = menu;
            options = new List<MenuOption>();

            width = ProbGuesser.width / 4;
            top = ProbGuesser.height / 3;
            optionsStart = new Vector2(ProbGuesser.width / 2 - width / 2, top);

            this.title = title;

            this.color = color;
            this.opacity = opacity;
        }

        List<MenuOption> options;
        int spacing = 7;
        Vector2 optionsStart;
        int width, top;
        String title;
        Color color;
        int opacity;
        Menu menu;

        public void AddOption(MenuOption m)
        {
            options.Add(m);
        }

        int selected = 0;

        public void Close()
        {
            menu.CloseScreen();
        }

        public void NavigateUp()
        {
            selected--;
            if (selected < 0) selected = options.Count - 1;
        }

        public void NavigateDown()
        {
            selected++;
            if (selected >= options.Count) selected = 0;
        }

        public void Left()
        {
            options[selected].Left();
        }

        public void Right()
        {
            options[selected].Right();
        }

        public void Select()
        {
            options[selected].Select();
        }

        public void Back()
        {
            options[selected].Back();
        }

        public void HeldLeft()
        {
            options[selected].HeldLeft();
        }

        public void HeldRight()
        {
            options[selected].HeldRight();
        }

        public int GetWidth()
        {
            return width;
        }

        public Menu GetMenu()
        {
            return menu;
        }

        public void Draw()
        {
            Color temp = new Color(color.R, color.G, color.B, opacity);
            ResourceManager.DrawRect(new Rect(0, 0, ProbGuesser.width, ProbGuesser.height), temp);

            ResourceManager.DrawText(optionsStart + new Vector2(8, -24), title, "BPFont");

            ResourceManager.DrawRect(new Rect(optionsStart.X, optionsStart.Y - 10, width, 2), Color.White);

            int yOffset = 0;

            for(int i = 0; i < options.Count; i++)
            {
                Vector2 position = optionsStart + new Vector2(4, yOffset);
                if (i == selected)
                {
                    options[i].DrawCursor(position);
                }
                options[i].Draw(position);
                yOffset += options[i].GetHeight() + spacing;
            }
        }
    }
}
