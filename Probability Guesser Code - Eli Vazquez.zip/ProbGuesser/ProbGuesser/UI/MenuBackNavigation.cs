﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuBackNavigation:MenuText
    {
        public MenuBackNavigation(MenuScreen screen, string text = "Back") : base(screen, text)
        {

        }

        public override void Select()
        {
            screen.Close();
            ResourceManager.PlaySFX("Good");
        }
    }
}
