﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuQuitNavigation : MenuText
    {
        public MenuQuitNavigation(MenuScreen screen) : base(screen, "Quit Game")
        {

        }

        public override void Select()
        {
            MenuScreen newScreen = new MenuScreen(screen.GetMenu(), "Quit", Color.Black, 100);
            newScreen.AddOption(new MenuQuitGame(newScreen, "Yes"));
            newScreen.AddOption(new MenuBackNavigation(newScreen, "No"));
            screen.GetMenu().AddScreen(newScreen);
            ResourceManager.PlaySFX("Good");
        }
    }
}
