﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuMasterVolumeSlider : MenuSlider
    {
        public MenuMasterVolumeSlider(MenuScreen screen) : base(screen, "Master Volume", 0)
        {
            SetPoints((int)(ResourceManager.GetMasterVolume() * GetMaxPoints()));
        }

        public override void OnSetPoints()
        {
            ResourceManager.SetMasterVolume(((float)GetPoints()) / GetMaxPoints());
        }
    }
}
