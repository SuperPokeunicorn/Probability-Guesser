﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    class MenuMusicSlider : MenuSlider
    {
        public MenuMusicSlider(MenuScreen screen) : base(screen, "Music Volume", 0)
        {
            SetPoints((int)(ResourceManager.GetSongVolume() * GetMaxPoints()));
        }

        public override void OnSetPoints()
        {
            ResourceManager.SetSongVolume(((float)GetPoints()) / GetMaxPoints());
        }
    }
}
