﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    abstract class MenuSelector : MenuOption
    {
        public MenuSelector(MenuScreen screen, string text, List<string> options) : base(screen, 18, 7)
        {
            this.text = text;
            this.options = options;
            selected = 0;

            holdTimer = false;
        }

        string text;
        List<string> options;
        int selected;

        public override void Draw(Vector2 position)
        {
            ResourceManager.DrawText(position, text);
            Vector2 optionsStart = position + new Vector2(0, 9);
            int offset = 0;
            for(int i = 0; i < options.Count; i++)
            {
                Color color = GetTextColor(i);
                ResourceManager.DrawText(optionsStart + new Vector2(offset, 0), options[i], r: color.R, g: color.G, b: color.B);
                offset += 7 * (options[i].Length + 1);
            }
        }

        public override void DrawCursor(Vector2 position)
        {
            Vector2 startPosition = position + new Vector2(-8, 9);
            int offset = 0;
            for (int i = 0; i < options.Count; i++)
            {
                if (selected == i)
                {
                    ResourceManager.DrawText(startPosition + new Vector2(offset, 0), ">", g: 0, b: 0);
                    break;
                }
                offset += 7 * (options[i].Length + 1);
            }
        }

        protected abstract Color GetTextColor(int i);

        protected abstract void OnSelect(int i);

        public override void OnLeft()
        {
            selected--;
            if (selected < 0) selected = options.Count - 1; ;
        }

        public override void OnRight()
        {
            selected++;
            if (selected >= options.Count) selected = 0;
        }

        public override void Select()
        {
            ResourceManager.PlaySFX("Good");
            OnSelect(selected);
        }
    }
}
