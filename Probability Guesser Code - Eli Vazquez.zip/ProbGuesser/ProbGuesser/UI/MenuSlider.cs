﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.UI
{
    abstract class MenuSlider : MenuOption
    {
        public MenuSlider(MenuScreen screen, string text, int points):base(screen, 18, 7)
        {
            this.text = text;
            this.points = points;
            max = (screen.GetWidth() - 3) / 2;
        }

        string text;
        int points, max;

        public override void Draw(Vector2 position)
        {
            ResourceManager.DrawText(position, text);
            ResourceManager.DrawRect(new Rect(position.X - 4, position.Y + 6, screen.GetWidth(), 9), Color.White);
            ResourceManager.DrawRect(new Rect(position.X - 3, position.Y + 7, screen.GetWidth() - 2, 7), Color.Black);
            for(int i = 0; i < points; i++)
            {
                ResourceManager.DrawRect(new Rect(position.X - 2 + i * 2, position.Y + 8, 1, 5), Color.White);
            }
        }

        public override void OnLeft()
        {
            if (points > 0)
            {
                SetPoints(points - 1);
                ResourceManager.PlaySFX("Good");
            }
            else ResourceManager.PlaySFX("Hit");
        }

        public override void OnRight()
        {
            if (points < max)
            {
                SetPoints(points + 1);
                ResourceManager.PlaySFX("Good");
            }
            else ResourceManager.PlaySFX("Hit");
        }

        public override void Select()
        {
            ResourceManager.PlaySFX("Hit");
        }

        public void SetPoints(int p)
        {
            points = p;
            OnSetPoints();
        }

        public abstract void OnSetPoints();

        public int GetPoints()
        {
            return points;
        }

        public int GetMaxPoints()
        {
            return max;
        }
    }
}
