﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.RandomVariables
{
    class BinomialRandomVariable : RandomVariable
    {
        public BinomialRandomVariable(int n, float p) : base(n)
        {
            this.n = n;
            this.p = p;

            id = 1;
        }

        int n;
        float p;

        public override float GenerateSample()
        {
            int count = 0;
            for (int i = 0; i < n; i++) count += ResourceManager.BernouliRandom(p);
            return count;
        }

        public override string ToString()
        {
            return "Bin(" + n + ", " + (p - p % .01) + ")";
        }

        public override bool TooSimilar(RandomVariable other)
        {
            if (id != other.GetId()) return false;

            BinomialRandomVariable b = (BinomialRandomVariable)other;
            if (Math.Abs(p - b.p) < .15 || n == b.n) return true;
            return false;
        }
    }
}
