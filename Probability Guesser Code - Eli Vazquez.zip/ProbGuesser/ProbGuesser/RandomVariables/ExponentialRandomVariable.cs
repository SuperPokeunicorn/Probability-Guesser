﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.RandomVariables
{
    class ExponentialRandomVariable : RandomVariable
    {
        public ExponentialRandomVariable(float lambda, float max) : base(max)
        {
            geo = new GeometricRandomVariable(lambda / 60000, 60000 * max);
            this.lambda = (lambda - lambda % .01f);

            id = 5;
        }

        GeometricRandomVariable geo;
        float lambda;

        public override float GenerateSample()
        {
            float value = geo.GenerateSample() / 60000;
            return value;
        }

        public override string ToString()
        {
            return "Exp(" + lambda + ")";
        }

        public override bool TooSimilar(RandomVariable other)
        {
            if (id != other.GetId()) return false;

            ExponentialRandomVariable b = (ExponentialRandomVariable)other;
            if (Math.Abs(lambda - b.lambda) < .1) return true;
            return false;
        }
    }
}
