﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser
{
    abstract class RandomVariable
    {
        public RandomVariable(float max)
        {
            this.max = max;
        }

        protected float max;
        protected int id;

        public abstract float GenerateSample();

        public abstract bool TooSimilar(RandomVariable other);

        public int GetId()
        {
            return id;
        }
    }
}
