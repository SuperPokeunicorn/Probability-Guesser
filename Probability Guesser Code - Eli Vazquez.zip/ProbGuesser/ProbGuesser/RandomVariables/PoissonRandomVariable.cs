﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.RandomVariables
{
    class PoissonRandomVariable : RandomVariable
    {
        public PoissonRandomVariable(float lambda, float max) : base(max)
        {
            bin = new BinomialRandomVariable(60000, lambda / 60000);
            this.lambda = (lambda - lambda % .1f);

            id = 2;
        }

        BinomialRandomVariable bin;
        float lambda;

        public override float GenerateSample()
        {
            float sample = bin.GenerateSample();
            return sample;
        }

        public override string ToString()
        {
            return "Poi(" + lambda + ")";
        }

        public override bool TooSimilar(RandomVariable other)
        {
            if (id != other.GetId()) return false;

            PoissonRandomVariable b = (PoissonRandomVariable)other;
            if (Math.Abs(lambda - b.lambda) < 1.2) return true;
            return false;
        }
    }
}
