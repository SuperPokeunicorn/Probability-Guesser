﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.RandomVariables
{
    class NegBinRandomVariable : RandomVariable
    {
        public NegBinRandomVariable(int r, float p, float max) : base(max)
        {
            this.r = r;
            geo = new GeometricRandomVariable(p, max);
            this.p = (p - p % .01f);

            id = 4;
        }

        int r;
        float p;
        GeometricRandomVariable geo;

        public override float GenerateSample()
        {
            int count = 0;
            for (int i = 0; i < r; i++) count += (int)geo.GenerateSample();
            return count;
        }

        public override string ToString()
        {
            return "NB(" + r + ", " + p + ")";
        }

        public override bool TooSimilar(RandomVariable other)
        {
            if (id != other.GetId()) return false;

            NegBinRandomVariable b = (NegBinRandomVariable)other;
            if (Math.Abs(p - b.p) < .15) return true;
            return false;
        }
    }
}
