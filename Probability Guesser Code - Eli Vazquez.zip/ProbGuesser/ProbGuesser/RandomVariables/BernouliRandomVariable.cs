﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.RandomVariables
{
    class BernouliRandomVariable : RandomVariable
    {
        public BernouliRandomVariable(float p) : base(1)
        {
            this.p = p;
            id = 8;
        }

        float p;

        public override float GenerateSample()
        {
            return ResourceManager.BernouliRandom(p);
        }

        public override string ToString()
        {
            return "Ber(" + (p - p % .01) + ")";
        }

        public override bool TooSimilar(RandomVariable other)
        {
            if (id != other.GetId()) return false;

            BernouliRandomVariable b = (BernouliRandomVariable)other;
            if (Math.Abs(p - b.p) < .15) return true;
            return false;
        }
    }
}
