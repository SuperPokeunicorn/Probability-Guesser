﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser
{
    class UniformRandomVariable : RandomVariable
    {
        public UniformRandomVariable(float min, float max) : base(max)
        {
            this.min = min;

            id = 0;
        }

        float min;

        public override float GenerateSample()
        {
            return ResourceManager.UniformRandom(min, max);
        }

        public override string ToString()
        {
            return "Uni(" + min + ", " + max + ")";
        }

        public override bool TooSimilar(RandomVariable other)
        {
            if (id != other.GetId()) return false;

            UniformRandomVariable u = (UniformRandomVariable)other;
            if (Math.Abs(min - u.min) < 1 || Math.Abs(max - u.max) < 1) return true;
            return false;
        }
    }
}
