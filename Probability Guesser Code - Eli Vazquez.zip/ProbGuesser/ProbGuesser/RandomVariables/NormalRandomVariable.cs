﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.RandomVariables
{
    class NormalRandomVariable : RandomVariable
    {
        public NormalRandomVariable(float mean, float var, float max) : base(max)
        {
            this.mean = mean;
            this.var = var;

            id = 6;
        }

        float mean, var;

        public override float GenerateSample()
        {
            float u1 = 1 - ResourceManager.UniformRandom(0, 1);
            float u2 = 1 - ResourceManager.UniformRandom(0, 1);

            float r = (float)Math.Sqrt(-2 * Math.Log(u1));
            float theta = (float)(u2 * 2 * Math.PI);

            float value = (float)(r * Math.Cos(theta));
            value *= var;
            value += mean;
            return value;
        }

        public override string ToString()
        {
            return "N(" + (mean - mean % .1) + ", " + (var - var % .1) + ")";
        }

        public override bool TooSimilar(RandomVariable other)
        {
            if (id != other.GetId()) return false;

            NormalRandomVariable b = (NormalRandomVariable)other;
            if (Math.Abs(mean - b.mean) < 1.2 && Math.Abs(var - b.var) < .7) return true;
            return false;
        }
    }
}
