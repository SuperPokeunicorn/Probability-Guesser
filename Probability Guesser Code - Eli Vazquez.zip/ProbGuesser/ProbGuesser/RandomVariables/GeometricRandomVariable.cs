﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.RandomVariables
{
    class GeometricRandomVariable : RandomVariable
    {
        public GeometricRandomVariable(float p, float max) : base(max)
        {
            this.p = p;
            id = 3;
        }

        float p;

        public override float GenerateSample()
        {
            int count = 1;
            while (ResourceManager.BernouliRandom(p) == 0) count++;
            return count;
        }

        public override string ToString()
        {
            return "Geo(" + (p - p % .01) + ")";
        }

        public override bool TooSimilar(RandomVariable other)
        {
            if (id != other.GetId()) return false;

            GeometricRandomVariable b = (GeometricRandomVariable)other;
            if (Math.Abs(p - b.p) < .15) return true;
            return false;
        }
    }
}
