﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser
{
    class Histogram
    {
        public Histogram(int cols, int maxColSamples)
        {
            //note: height should be divisible by maxColSamples and width should be divisible by cols
            this.cols = cols;
            this.maxColSamples = maxColSamples;
            samples = new List<int>();
            for(int i = 0; i < cols; i++)
            {
                samples.Add(0);
            }
        }

        int cols;
        List<int> samples;
        int height = 140;
        int width = 180;
        int maxColSamples = 20;
        int boarderStroke = 2;
        int gridStoke = 1;
        int xStart = 20;
        int yStart = 20;

        public void AddSample(float value)
        {
            int col = (int)value;
            if(col >= cols)
            {
                samples[cols - 1]++;
            }
            else if(col < 0)
            {
                samples[0]++;
            }
            else
            {
                samples[col]++;
            }
        }

        public void Draw()
        {
            //Vertical boarder line
            ResourceManager.DrawRect(new Rect(xStart, yStart - boarderStroke, boarderStroke, height + boarderStroke), Color.White);

            //Horizontal boarder line
            ResourceManager.DrawRect(new Rect(xStart, yStart + height - boarderStroke, width + boarderStroke, boarderStroke), Color.White);

            //Samples
            for(int col = 0; col < cols; col++)
            {
                for(int row = 0; row < samples[col]; row++)
                {
                    ResourceManager.DrawRect(new Rect(xStart + boarderStroke + col * (width/cols), yStart + height - boarderStroke - (height / maxColSamples) * (row + 1), 
                        (width / cols), (height / maxColSamples)), Color.Red);
                }
            }

            ResourceManager.DrawText(new Vector2(xStart - gridStoke + boarderStroke, yStart + height + 6), "0-");

            //Vertical grid lines
            for(int i = 1; i <= cols; i++)
            {
                ResourceManager.DrawRect(new Rect(xStart - gridStoke + boarderStroke + (width / cols) * i, yStart - boarderStroke, gridStoke, height), Color.Gray);
                ResourceManager.DrawText(new Vector2(xStart - gridStoke + boarderStroke + (width / cols) * i - (("" + i).Length - 1) * 7 / 2, yStart + height + 6), i + (i == cols ? "+" : ""));
            }

            //Horizontal grid lines
            for(int i = 0; i < maxColSamples; i++)
            {
                ResourceManager.DrawRect(new Rect(xStart + boarderStroke, yStart + (height / maxColSamples) * i - boarderStroke, width, gridStoke), Color.Gray);
            }
        }
    }
}
