<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="LD44Tiles" tilewidth="8" tileheight="8" tilecount="352" columns="32">
 <image source="../Content/LD44Tiles.png" width="256" height="88"/>
</tileset>
