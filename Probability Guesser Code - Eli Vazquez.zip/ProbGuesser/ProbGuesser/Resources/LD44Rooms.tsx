<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="LD44Rooms" tilewidth="8" tileheight="8" tilecount="32" columns="8">
 <image source="BloodPressureRooms.png" width="64" height="32"/>
</tileset>
