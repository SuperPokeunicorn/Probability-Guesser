<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="LD44Entities" tilewidth="8" tileheight="8" tilecount="45" columns="9">
 <image source="LD44Entities.png" width="72" height="40"/>
</tileset>
