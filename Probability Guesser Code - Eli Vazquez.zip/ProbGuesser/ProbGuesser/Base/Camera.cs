﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.Base
{
    class Camera
    {
        public Camera(Vector2 position)
        {
            this.position = position;
        }

        Vector2 position;

        public Vector2 GetDrawPosition()
        {
            return position;
        }
    }
}
