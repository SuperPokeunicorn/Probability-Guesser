﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser
{
    static class InputManager
    {
        public static void SetInput(string input, Keys key)
        {
            inputs[input] = key;
        }

        public static void UpdateInput(KeyboardState k)
        {
            pressed.Clear();
            released.Clear();
            foreach(KeyValuePair<string, Keys> input in inputs)
            {
                if (!keyboard.IsKeyDown(input.Value) && k.IsKeyDown(input.Value)) pressed.Add(input.Key);
                if (keyboard.IsKeyDown(input.Value) && !k.IsKeyDown(input.Value)) released.Add(input.Key);
            }
            keyboard = k;
        }

        static KeyboardState keyboard = new KeyboardState();
        static Dictionary<string, Keys> inputs = new Dictionary<string, Keys>();
        static HashSet<string> pressed = new HashSet<string>();
        static HashSet<string> released = new HashSet<string>();

        public static bool IsHeld(string input)
        {
            if (!inputs.ContainsKey(input)) return false;
            return keyboard.IsKeyDown(inputs[input]);
        }

        public static bool IsPressed(string input)
        {
            return pressed.Contains(input);
        }

        public static bool IsReleased(string input)
        {
            return released.Contains(input);
        }
    }
}
