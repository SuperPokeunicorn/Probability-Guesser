﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class ProbGuesser : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        RenderTarget2D target;
        GameStateManager gsm;

        public static int width = 320;
        public static int height = 180;
        public static bool debug = false;
        float scale = 3;
        
        public static KeyboardState currKeyboard;
        KeyboardState prevKeyboard;
        MouseState mouseState;

        public static bool quitGame = false;
        private static bool changeScale = false;
        private static float newScale = 3;
        private static bool fullScreen = false;

        public ProbGuesser()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            Window.Title = "Probability Guesser";
            SetWindowSize(scale, false);

            currKeyboard = new KeyboardState();
            prevKeyboard = new KeyboardState();
            mouseState = new MouseState();

            InputManager.SetInput("left", Keys.Left);
            InputManager.SetInput("right", Keys.Right);
            InputManager.SetInput("up", Keys.Up);
            InputManager.SetInput("down", Keys.Down);

            InputManager.SetInput("sample", Keys.Space);

            InputManager.SetInput("1", Keys.D1);
            InputManager.SetInput("2", Keys.D2);
            InputManager.SetInput("3", Keys.D3);
            InputManager.SetInput("4", Keys.D4);
            InputManager.SetInput("5", Keys.D5);

            InputManager.SetInput("pause", Keys.Escape);
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // initialization logic
            spriteBatch = new SpriteBatch(GraphicsDevice);
            ResourceManager.SetSpriteBatch(spriteBatch);
            target = new RenderTarget2D(GraphicsDevice, width, height);
            gsm = new GameStateManager(this, spriteBatch);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // use this.Content to load game content

            //Songs
            LoadSong("ProbabilityPower");

            //SFX
            LoadSFX("Death");
            LoadSFX("Win");
            LoadSFX("Hit");
            LoadSFX("Good");

            //Text
            LoadTexture("BPFont");
            LoadTexture("BPFontSmall");

            //Misc
            LoadTexture("Pixel");

            gsm.Initialize();
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // Unload any non ContentManager content
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            ResourceManager.ManageSFX();
            currKeyboard = Keyboard.GetState();
            InputManager.UpdateInput(currKeyboard);
            foreach(Keys k in currKeyboard.GetPressedKeys())
            {
                if(prevKeyboard.IsKeyUp(k))
                {
                    gsm.KeyPressed(k);
                }
            }

            foreach (Keys k in prevKeyboard.GetPressedKeys())
            {
                if (currKeyboard.IsKeyUp(k))
                {
                    gsm.KeyReleased(k);
                }
            }

            prevKeyboard = currKeyboard;
            mouseState = Mouse.GetState();

            // update logic
            gsm.Update(gameTime);

            base.Update(gameTime);

            if (quitGame) this.Exit();
            if (changeScale)
            {
                changeScale = false;
                SetWindowSize(newScale, fullScreen);
            }
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            GraphicsDevice.SetRenderTarget(target);

            // drawing code
            gsm.Draw(gameTime);

            GraphicsDevice.SetRenderTarget(null);

            spriteBatch.Begin(samplerState: SamplerState.PointClamp);

            
            int xOffset = 0;
            int yOffset = 0;
            /*
            if(graphics.IsFullScreen)
            {
                xOffset = (int) Math.Max((GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width - scale * width) / 4, 0);
                yOffset = (int) Math.Max((GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height - scale * height) / 4, 0);
            }
            */

            spriteBatch.Draw(target, new Rectangle(xOffset, yOffset, (int)(width * scale), (int)(height * scale)), Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }

        public void LoadTexture(String name)
        {
            ResourceManager.AddTexture(name, Content.Load<Texture2D>(name));
        }

        public void LoadSong(String name)
        {
            ResourceManager.AddSong(name, Content.Load<Song>(name));
        }

        public void LoadSFX(String name)
        {
            ResourceManager.AddSFX(name, Content.Load<SoundEffect>(name));
        }

        private void SetWindowSize(float scale, bool full)
        {
            this.scale = full ? 5 : scale;
            graphics.PreferredBackBufferWidth = (int)(width * this.scale);
            graphics.PreferredBackBufferHeight = (int)(height * this.scale);
            graphics.IsFullScreen = full;
            graphics.ApplyChanges();
        }

        public static void SetScale(float scale)
        {
            newScale = scale;
            fullScreen = false;
            changeScale = true;
        }

        public static void SetFullscreen(bool full)
        {
            fullScreen = full;
            changeScale = true;
        }

        public static float GetScale()
        {
            return fullScreen ? 5 : newScale;
        }

        public static bool GetFullscreen()
        {
            return fullScreen;
        }
    }
}
