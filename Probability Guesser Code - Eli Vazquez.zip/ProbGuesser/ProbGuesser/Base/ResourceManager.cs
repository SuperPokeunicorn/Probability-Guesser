﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using ProbGuesser.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser
{
    static class ResourceManager
    {
        //Visuals
        static SpriteBatch spriteBatch;
        static public Dictionary<string, Texture2D> textures = new Dictionary<string, Texture2D>();
        static public Dictionary<string, Color[,]> colorMaps = new Dictionary<string, Color[,]>();

        //Audio
        static public Dictionary<string, Song> songs = new Dictionary<string, Song>();
        static public Dictionary<string, SoundEffect> sfx = new Dictionary<string, SoundEffect>();
        static private List<SoundEffectInstance> sfxInstances = new List<SoundEffectInstance>();
        static private string curSong = "";
        static private float songVolume = .3f;
        static private float sfxVolume = .3f;
        static private float masterVolume = .3f;

        //Utility
        static public Random random = new Random();

        public static void SetSpriteBatch(SpriteBatch sb)
        {
            spriteBatch = sb;
        }

        public static void AddTexture(String name, Texture2D texture)
        {
            textures[name] = texture;
            Color[] colorData = new Color[texture.Width * texture.Height];
            texture.GetData<Color>(0, new Rectangle(0, 0, texture.Width, texture.Height), 
                colorData, 0, texture.Width * texture.Height);
            Color[,] colors2D = new Color[texture.Width, texture.Height];
            for (int x = 0; x < texture.Width; x++)
            {
                for (int y = 0; y < texture.Height; y++)
                {
                    colors2D[x, y] = colorData[x + y * texture.Width];
                }
            }
            colorMaps[name] = colors2D;
        }

        public static Texture2D GetTexture(String name)
        {
            return textures[name];
        }

        public static Color GetTexturePixelColor(String name, int x, int y)
        {
            return colorMaps[name][x, y];
        }

        public static void DrawTexture(String name, Vector2 possition,
            float xScale = 1, float yScale = 1, float scale = 1, float rotation = 0,
            bool flipHorizontally = false, bool flipVertically = false, float layerDepth = 0)
        {
            spriteBatch.Draw(textures[name],
                new Rectangle((int)possition.X, (int)possition.Y, 
                (int)(textures[name].Width * xScale * scale),(int)(textures[name].Height * yScale * scale)), null,
                Color.White, rotation, new Vector2(textures[name].Width / 2, textures[name].Height / 2),
                (flipHorizontally ? SpriteEffects.FlipHorizontally : SpriteEffects.None) |
                (flipVertically ? SpriteEffects.FlipVertically : SpriteEffects.None), layerDepth);
        }

        public static void DrawTextureScaled(String name, Vector2 possition,
            int width, int height, float rotation = 0,
            bool flipHorizontally = false, bool flipVertically = false, float layerDepth = 0)
        {
            spriteBatch.Draw(textures[name],
                new Rectangle((int)possition.X, (int)possition.Y, width, height), null,
                Color.White, rotation, new Vector2(textures[name].Width / 2, textures[name].Height / 2),
                (flipHorizontally ? SpriteEffects.FlipHorizontally : SpriteEffects.None) |
                (flipVertically ? SpriteEffects.FlipVertically : SpriteEffects.None), layerDepth);
        }

        public static void DrawSubTexture(String name, Vector2 possition,
            int x, int y, int width, int height,
            float xScale = 1, float yScale = 1, float scale = 1, float rotation = 0,
            bool flipHorizontally = false, bool flipVertically = false, float layerDepth = 0, 
            int r = 255, int g = 255, int b = 255, float a = 1)
        {
            spriteBatch.Draw(textures[name],
                new Rectangle((int)possition.X, (int)possition.Y,
                (int)(width * xScale * scale), (int)(height * yScale * scale)),
                new Rectangle(x, y, width, height),
                new Color(r, g, b) * a, rotation, new Vector2(width / 2, height / 2),
                (flipHorizontally ? SpriteEffects.FlipHorizontally : SpriteEffects.None) |
                (flipVertically ? SpriteEffects.FlipVertically : SpriteEffects.None), layerDepth);
        }

        public static void DrawRect(Rect rect, Color color, float rotation = 0,
            bool flipHorizontally = false, bool flipVertically = false, float layerDepth = 0)
        {
            spriteBatch.Draw(textures["Pixel"],
                new Rectangle((int)rect.x, (int)rect.y, (int)rect.width, (int)rect.height), null,
                color, rotation, new Vector2(textures["Pixel"].Width / 2, textures["Pixel"].Height / 2),
                (flipHorizontally ? SpriteEffects.FlipHorizontally : SpriteEffects.None) |
                (flipVertically ? SpriteEffects.FlipVertically : SpriteEffects.None), layerDepth);
        }

        public static void DrawRect(Rect rect, Color color, Camera cam, float rotation = 0,
            bool flipHorizontally = false, bool flipVertically = false, float layerDepth = 0)
        {
            spriteBatch.Draw(textures["Pixel"],
                new Rectangle((int)(rect.x - cam.GetDrawPosition().X), (int)(rect.y - cam.GetDrawPosition().Y),
                (int)rect.width, (int)rect.height), null,
                color, rotation, new Vector2(textures["Pixel"].Width / 2, textures["Pixel"].Height / 2),
                (flipHorizontally ? SpriteEffects.FlipHorizontally : SpriteEffects.None) |
                (flipVertically ? SpriteEffects.FlipVertically : SpriteEffects.None), layerDepth);
        }

        public static void DrawText(Vector2 position, string text, string font = "BPFontSmall", int leading = 2, int r = 255, int g = 255, int b = 255, int a = 255)
        {
            string upperText = text.ToUpper();
            char[] textArray = upperText.ToCharArray();
            float xOffset = 0;
            float yOffset = 0;
            int charWidth = textures[font].Width;
            int charHeight = textures[font].Height / 59;
            for (int i = 0; i < textArray.Length; i++)
            {
                if (textArray[i] == '\n')
                {
                    xOffset = 0;
                    yOffset += charHeight + leading;
                }
                else
                {
                    DrawSubTexture(font, position + new Vector2(xOffset, yOffset), 0, charHeight * (textArray[i] - 32), charWidth, charHeight, r: r, g: g, b: b, a: a);
                    xOffset += charWidth;
                }
            }
        }

        public static float UniformRandom(float min, float max)
        {
            return (float)(ResourceManager.random.NextDouble() * (max - min) + min);
        }

        public static int BernouliRandom(float p)
        {
            float value = (float)random.NextDouble();
            if (value <= p) return 1;
            return 0;
        }

        public static void AddSong(string name, Song song)
        {
            songs[name] = song;
        }

        public static void PlaySong(string name, bool loop = false, float volume = 1)
        {
            if (curSong == name && MediaPlayer.State == MediaState.Playing) return;
            volume *= songVolume * masterVolume;
            MediaPlayer.Stop();
            MediaPlayer.IsRepeating = loop;
            MediaPlayer.Volume = volume;
            curSong = name;
            MediaPlayer.Play(songs[name]);
        }

        public static void StopSong()
        {
            curSong = "";
            MediaPlayer.Stop();
        }

        public static void AddSFX(string name, SoundEffect sound)
        {
            sfx[name] = sound;
        }

        public static void PlaySFX(string name, float volume = 1f, float pitch = 0, float pan = 0)
        {
            if (!sfx.ContainsKey(name)) return;
            volume *= sfxVolume * masterVolume;
            SoundEffectInstance instance = sfx[name].CreateInstance();
            instance.Volume = volume;
            instance.Pitch = pitch;
            instance.Pan = pan;
            if (sfxInstances.Count >= 16)
            {
                sfxInstances[0].Stop();
                sfxInstances.RemoveAt(0);
            }
            instance.Play();
            sfxInstances.Add(instance);
        }

        public static void ManageSFX()
        {
            while (sfxInstances.Count >= 16)
            {
                sfxInstances[0].Stop();
                sfxInstances.RemoveAt(0);
            }
            for (int i = sfxInstances.Count - 1; i >= 0; i--)
            {
                if(sfxInstances[i].State == SoundState.Stopped)
                {
                    sfxInstances.RemoveAt(i);
                }
            }
        }

        public static void SetSongVolume(float volume)
        {
            if (volume < 0) volume = 0;
            else if (volume > 1) volume = 1;
            songVolume = volume;
            MediaPlayer.Volume = songVolume * masterVolume;
        }

        public static float GetSongVolume()
        {
            return songVolume;
        }

        public static void SetSFXVolume(float volume)
        {
            if (volume < 0) volume = 0;
            else if (volume > 1) volume = 1;
            sfxVolume = volume;
        }

        public static float GetSFXVolume()
        {
            return sfxVolume;
        }

        public static void SetMasterVolume(float volume)
        {
            if (volume < 0) volume = 0;
            else if (volume > 1) volume = 1;
            masterVolume = volume;
            MediaPlayer.Volume = songVolume * masterVolume;
        }

        public static float GetMasterVolume()
        {
            return masterVolume;
        }
    }
}
