﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using ProbGuesser.RandomVariables;
using ProbGuesser.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser.Game_State
{
    class GuesserState : GameState
    {
        public GuesserState(GameStateManager gsm) : base(gsm)
        {
            menu = new Menu();
        }

        Histogram histogram;
        int correctChoice;
        List<RandomVariable> choices;
        int score = 0;
        int drawScore = 0;
        int points = 0;
        bool guessing = true;
        bool correct = true;

        int round = 0;

        Menu menu;

        public override void Draw(GameTime gameTime)
        {
            ResourceManager.DrawText(new Vector2(24, 10), "Round " + round + " - space to sample");

            histogram.Draw();
            ResourceManager.DrawText(new Vector2(215, 24), "Points: " + points);
            ResourceManager.DrawText(new Vector2(215, 34), "Score:  " + drawScore);

            if (guessing)
            {
                ResourceManager.DrawText(new Vector2(215, 80 - 22), "What's the");
                ResourceManager.DrawText(new Vector2(215, 80 - 12), "distribution?");
                for (int i = 0; i < choices.Count; i++)
                {
                    ResourceManager.DrawText(new Vector2(215, 85 + 12 * i), (i + 1) + ":" + choices[i]);
                }
            }

            if(!guessing)
            {
                ResourceManager.DrawText(new Vector2(215, 80 - 22), correct ? "Correct!" : "Incorrect", r: correct ? 0 : 255, g: correct ? 255 : 0, b: 0);
                ResourceManager.DrawText(new Vector2(215, 85), "Answer:");
                ResourceManager.DrawText(new Vector2(215, 85 + 12), choices[correctChoice].ToString());
                ResourceManager.DrawText(new Vector2(215, 85 + 36), "SPACE to");
                ResourceManager.DrawText(new Vector2(215, 85 + 48), "play again");
            }

            if(menu.IsOpen())
            {
                menu.Draw();
            }
        }

        public override void Initialize()
        {
            histogram = new Histogram(10, 20);
            GenerateRandomChoices();
            points = 100;
            guessing = true;
            round++;
        }

        public void GenerateRandomChoices()
        {
            choices = new List<RandomVariable>();
            for (int i = 0; i < 5; i++)
            {
                RandomVariable r = GenerateRandomVairable();
                while(TooSimilar(r))
                {
                    r = GenerateRandomVairable();
                }
                choices.Add(r);
            }
            correctChoice = (int)ResourceManager.UniformRandom(0, 5);

            ResourceManager.PlaySong("ProbabilityPower", true);
        }

        public RandomVariable GenerateRandomVairable()
        {
            /*
            else if (choice < 2)
            {
                histogram = new Histogram(2, 35);
                random = new BernouliRandomVariable(ResourceManager.UniformRandom(0, 1));
            }
             */


            RandomVariable random;
            int choice = (int)ResourceManager.UniformRandom(0, 7);
            if (choice == 0)
            {
                random = new UniformRandomVariable(0, 10);
            }
            else if (choice == 1)
            {
                random = new BinomialRandomVariable((int)ResourceManager.UniformRandom(7, 11), ResourceManager.UniformRandom(.3f, .7f));
            }
            else if (choice == 2)
            {
                random = new PoissonRandomVariable(ResourceManager.UniformRandom(3, 7), 10);
            }
            else if (choice == 3)
            {
                random = new GeometricRandomVariable(ResourceManager.UniformRandom(.2f, .5f), 9);
            }
            else if (choice == 4)
            {
                random = new NegBinRandomVariable((int)ResourceManager.UniformRandom(2, 4), ResourceManager.UniformRandom(.3f, .7f), 9);
            }
            else if (choice == 5)
            {
                random = new ExponentialRandomVariable(1 / ResourceManager.UniformRandom(3, 7), 10);
            }
            else
            {
                random = new NormalRandomVariable(ResourceManager.UniformRandom(3, 7), ResourceManager.UniformRandom(1, 3), 10);
            }

            return random;
        }

        bool TooSimilar(RandomVariable r1)
        {
            foreach(RandomVariable r2 in choices)
            {
                if (r1.TooSimilar(r2)) return true;
            }
            return false;
        }

        public override void KeyPressed(Keys key)
        {

        }

        public override void KeyReleased(Keys key)
        {

        }

        public void OpenMenu()
        {
            MenuScreen screen = new MenuScreen(menu, "Pause", Color.Black, 100);
            screen.AddOption(new MenuBackNavigation(screen, "Continue"));
            screen.AddOption(new MenuSoundNavigation(screen));
            screen.AddOption(new MenuVideoNavigation(screen));
            screen.AddOption(new MenuQuitNavigation(screen));
            menu.AddScreen(screen);
            ResourceManager.PlaySFX("Good");

            ResourceManager.StopSong();
        }

        public void Guess(int i)
        {
            correct = i == correctChoice;
            if (correct)
            {
                score += points;
                ResourceManager.PlaySFX("Win");
            }
            else
            {
                ResourceManager.PlaySFX("Death");
            }
            guessing = false;

            ResourceManager.StopSong();
        }

        public override void Update(GameTime gameTime)
        {
            if (!menu.IsOpen())
            {
                if (InputManager.IsPressed("pause"))
                {
                    OpenMenu();
                    return;
                }
                if (drawScore < score)
                {
                    drawScore++;
                }
                else if (drawScore > score)
                {
                    drawScore--;
                }
                if (guessing)
                {
                    if (InputManager.IsPressed("sample"))
                    {
                        if (points > 1)
                        {
                            histogram.AddSample(choices[correctChoice].GenerateSample());
                            points--;
                            ResourceManager.PlaySFX("Good");
                        }
                        else
                        {
                            ResourceManager.PlaySFX("Hit");
                        }
                    }
                    if (InputManager.IsPressed("1"))
                    {
                        Guess(0);
                    }
                    else if (InputManager.IsPressed("2"))
                    {
                        Guess(1);
                    }
                    else if (InputManager.IsPressed("3"))
                    {
                        Guess(2);
                    }
                    else if (InputManager.IsPressed("4"))
                    {
                        Guess(3);
                    }
                    else if (InputManager.IsPressed("5"))
                    {
                        Guess(4);
                    }
                }
                else
                {
                    if (points > 0) points--;
                    if (InputManager.IsPressed("sample"))
                    {
                        ResourceManager.PlaySFX("Good");
                        Initialize();
                    }
                }
            }
            else
            {
                if (InputManager.IsPressed("pause"))
                {
                    menu.Back();
                }

                if (menu.IsOpen()) 
                {
                    if (InputManager.IsPressed("up")) menu.NavigateUp();
                    if (InputManager.IsPressed("down")) menu.NavigateDown();
                    if (InputManager.IsPressed("sample")) menu.Select();
                }

                if (menu.IsOpen())
                {
                    if (InputManager.IsPressed("left")) menu.Left();
                    if (InputManager.IsPressed("right")) menu.Right();

                    if (InputManager.IsHeld("left")) menu.HeldLeft();
                    if (InputManager.IsHeld("right")) menu.HeldRight();
                }

                if(!menu.IsOpen())
                {
                    ResourceManager.PlaySong("ProbabilityPower", true);
                }
            }
        }
    }
}
