﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using ProbGuesser.Game_State;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProbGuesser
{
    class GameStateManager
    {
        public Game baseGame;
        public SpriteBatch spriteBatch;

        Dictionary<String, GameState> gameStates;
        string currState = "";
        string defaultState = "guesser";

        public GameStateManager(Game baseGame, SpriteBatch spriteBatch)
        {
            this.baseGame = baseGame;
            this.spriteBatch = spriteBatch;
            gameStates = new Dictionary<String, GameState>();
        }

        public void Initialize()
        {
            gameStates["guesser"] = new GuesserState(this);
            SetState(defaultState);
        }

        public void SetState(string state)
        {
            if (state == currState) return;
            if (!gameStates.ContainsKey(state)) return;

            gameStates[state].Initialize();
            currState = state;
        }

        public void KeyPressed(Keys k)
        {
            gameStates[currState].KeyPressed(k);
        }

        public void KeyReleased(Keys k)
        {
            gameStates[currState].KeyReleased(k);
        }

        public void Update(GameTime gameTime)
        {
            gameStates[currState].Update(gameTime);
        }

        public void Draw(GameTime gameTime)
        {
            spriteBatch.Begin(samplerState: SamplerState.PointClamp);

            gameStates[currState].Draw(gameTime);

            spriteBatch.End();
        }
    }
}
